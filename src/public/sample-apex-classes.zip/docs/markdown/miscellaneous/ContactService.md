# ContactService Class

Service class for managing Contact records and related operations. 
Provides utility methods for creating contacts from leads, retrieving contacts by account, 
deduplicating contacts, validating email addresses, and updating communication preferences. 
Includes error handling for database operations and maintains data integrity through validation.

**Author** {AUTHOR_NAME}

## Methods
### `createContactsFromLeads(convertedLeads, accountId)`

Creates Contact records from a list of converted Lead records. 
Skips leads without email addresses and assigns all contacts to the specified account.

#### Signature
```apex
public static List<Contact> createContactsFromLeads(List<Lead> convertedLeads, Id accountId)
```

#### Parameters
| Name | Type | Description |
|------|------|-------------|
| convertedLeads | List&lt;Lead&gt; | List of Lead records to convert into Contact records |
| accountId | Id | The Account ID to associate with all created Contact records |

#### Return Type
**List&lt;Contact&gt;**

List of Contact records created from the provided leads

---

### `getContactsByAccountId(accountIds)`

Retrieves the most recently created contact for each specified account. 
Returns a map where each account ID is associated with its newest contact record. 
If an account has no contacts, it will not appear in the returned map.

#### Signature
```apex
public static Map<Id,Contact> getContactsByAccountId(Set<Id> accountIds)
```

#### Parameters
| Name | Type | Description |
|------|------|-------------|
| accountIds | Set&lt;Id&gt; | Set of account IDs to retrieve contacts for |

#### Return Type
**Map&lt;Id,Contact&gt;**

Map of account IDs to their most recently created contact records

---

### `deduplicateContacts(contacts)`

Removes duplicate contacts from the provided list based on email address. 
Contacts with the same normalized email address (case-insensitive, trimmed) are considered duplicates. 
The first contact encountered with a unique email is preserved, while subsequent duplicates are deleted. 
Contacts with blank or null email addresses are ignored and not processed for deduplication.

#### Signature
```apex
public static List<Database.SaveResult> deduplicateContacts(List<Contact> contacts)
```

#### Parameters
| Name | Type | Description |
|------|------|-------------|
| contacts | List&lt;Contact&gt; | the list of contacts to deduplicate |

#### Return Type
**List&lt;Database.SaveResult&gt;**

a list of Database.SaveResult objects representing the deletion results for duplicate contacts,,[object Object],        or an empty list if no duplicates were found

---

### `validateContactEmail(email)`

`TESTVISIBLE`

#### Signature
```apex
private static Boolean validateContactEmail(String email)
```

#### Parameters
| Name | Type | Description |
|------|------|-------------|
| email | String |  |

#### Return Type
**Boolean**

---

### `updateContactPreferences(contacts, optInEmail, optInPhone)`

Updates contact communication preferences for a list of contacts. 
Sets email and phone opt-in preferences by updating the HasOptedOutOfEmail 
and DoNotCall fields respectively.

#### Signature
```apex
public static void updateContactPreferences(List<Contact> contacts, Boolean optInEmail, Boolean optInPhone)
```

#### Parameters
| Name | Type | Description |
|------|------|-------------|
| contacts | List&lt;Contact&gt; | List of Contact records to update preferences for |
| optInEmail | Boolean | Boolean indicating whether contacts should opt-in to email communications |
| optInPhone | Boolean | Boolean indicating whether contacts should opt-in to phone communications |

#### Return Type
**void**

---

### `handleSaveErrors(results, operationName)`

`TESTVISIBLE`

Handles and logs errors from database save operations. 
Iterates through save results and logs detailed error information for any failed operations, 
including the record ID, status code, and error message.

#### Signature
```apex
private static void handleSaveErrors(List<Database.SaveResult> results, String operationName)
```

#### Parameters
| Name | Type | Description |
|------|------|-------------|
| results | List&lt;Database.SaveResult&gt; | the list of Database.SaveResult objects to process for errors |
| operationName | String | the name of the operation being performed, used for logging context |

#### Return Type
**void**