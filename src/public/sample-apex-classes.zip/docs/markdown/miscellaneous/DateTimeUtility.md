# DateTimeUtility Class

Utility class providing date and time manipulation methods for Salesforce applications. 
Includes functionality for timezone conversion, business day calculations, relative date formatting, 
and ISO date parsing. All methods are static and designed for reusability across different contexts.

**Author** {AUTHOR_NAME}

## Methods
### `convertToTimezone(sourceDateTime, targetTimezone)`

Converts a DateTime from its current timezone to a specified target timezone. 
Uses an internal timezone mapping to resolve common timezone abbreviations to full timezone identifiers.

#### Signature
```apex
public static DateTime convertToTimezone(DateTime sourceDateTime, String targetTimezone)
```

#### Parameters
| Name | Type | Description |
|------|------|-------------|
| sourceDateTime | DateTime | the DateTime to convert, can be null |
| targetTimezone | String | the target timezone identifier or abbreviation |

#### Return Type
**DateTime**

the converted DateTime in the target timezone, or null if sourceDateTime is null

---

### `getBusinessDaysBetween(startDate, endDate)`

Calculates the number of business days (Monday through Friday) between two dates, inclusive. 
Weekends (Saturday and Sunday) are excluded from the count.

#### Signature
```apex
public static Integer getBusinessDaysBetween(Date startDate, Date endDate)
```

#### Parameters
| Name | Type | Description |
|------|------|-------------|
| startDate | Date | the beginning date of the range (inclusive) |
| endDate | Date | the ending date of the range (inclusive) |

#### Return Type
**Integer**

the number of business days between the dates, or 0 if parameters are invalid

---

### `formatRelativeDate(targetDateTime)`

Formats a DateTime into a human-readable relative date string. 
Returns formatted strings like &quot;2 days ago&quot;, &quot;Yesterday&quot;, &quot;3 hours ago&quot;, or the actual date for older entries. 
For dates older than 30 days, returns the formatted date (e.g., &quot;Jan 15, 2024&quot;).

#### Signature
```apex
public static String formatRelativeDate(DateTime targetDateTime)
```

#### Parameters
| Name | Type | Description |
|------|------|-------------|
| targetDateTime | DateTime | the DateTime to format relative to the current time |

#### Return Type
**String**

a human-readable relative date string, or &quot;Unknown&quot; if targetDateTime is null

---

### `getNextBusinessDay(fromDate)`

Calculates the next business day (Monday through Friday) from a given date. 
If the provided date is null, uses today&#x27;s date as the starting point. 
Skips weekends to find the next weekday.

#### Signature
```apex
public static Date getNextBusinessDay(Date fromDate)
```

#### Parameters
| Name | Type | Description |
|------|------|-------------|
| fromDate | Date | the starting date to calculate from, or null to use today&#x27;s date |

#### Return Type
**Date**

the next business day after the provided date

---

### `isWeekend(checkDate)`

`TESTVISIBLE`

Determines if the given date falls on a weekend (Saturday or Sunday).

#### Signature
```apex
private static Boolean isWeekend(Date checkDate)
```

#### Parameters
| Name | Type | Description |
|------|------|-------------|
| checkDate | Date | the date to evaluate for weekend status |

#### Return Type
**Boolean**

true if the date is Saturday or Sunday, false otherwise

---

### `parseISODateRange(isoStart, isoEnd)`

Parses ISO 8601 formatted date strings into a DateTime range map. 
Converts ISO date strings by removing &#x27;T&#x27; and &#x27;Z&#x27; characters and creates 
a map with &#x27;start&#x27; and &#x27;end&#x27; keys. If the start date is after the end date, 
the values are automatically swapped to ensure proper chronological order.

#### Signature
```apex
public static Map<String,DateTime> parseISODateRange(String isoStart, String isoEnd)
```

#### Parameters
| Name | Type | Description |
|------|------|-------------|
| isoStart | String | the ISO 8601 formatted start date string |
| isoEnd | String | the ISO 8601 formatted end date string |

#### Return Type
**Map&lt;String,DateTime&gt;**

a Map containing &#x27;start&#x27; and &#x27;end&#x27; DateTime values, or null if parsing fails