# Reference Guide

## Miscellaneous

### [ContactService](miscellaneous\ContactService.md)

Service class for managing Contact records and related operations. 
Provides utility methods for creating contacts from leads, retrieving contacts by account, 
deduplicating contacts, validating email addresses, and updating communication preferences. 
Includes error handling for database operations and maintains data integrity through validation.

### [DateTimeUtility](miscellaneous\DateTimeUtility.md)

Utility class providing date and time manipulation methods for Salesforce applications. 
Includes functionality for timezone conversion, business day calculations, relative date formatting, 
and ISO date parsing. All methods are static and designed for reusability across different contexts.